#include <QCoreApplication>
#include <QtTest>
#include "test_functions.h"

int main(int argc, char *argv[]) {
    QCoreApplication app(argc, argv);
    TestFunctions test;
    return QTest::qExec(&test, argc, argv);
}
