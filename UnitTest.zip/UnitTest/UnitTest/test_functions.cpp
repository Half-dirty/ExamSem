#include "test_functions.h"
#include "database.h"
#include <QSqlQuery>
#include <QSqlError>
#include <cstdlib>
#include <ctime>

void TestFunctions::initTestCase() {
    Database::getInstance(); // ОБЯЗАТЕЛЬНО!
}

void TestFunctions::testGetExamListJSON() {
    QTcpSocket dummySocket;
    QMap<QTcpSocket*, int> userIds;
    Functions functions(&dummySocket, userIds);

    QJsonArray result = functions.getExamListJSON();
    QVERIFY(!result.isEmpty());
    QVERIFY(result[0].toObject().contains("id"));
    QVERIFY(result[0].toObject().contains("name"));
}

void TestFunctions::testRegisterUser() {
    srand(static_cast<unsigned>(time(nullptr)));

    QTcpSocket dummySocket;
    QMap<QTcpSocket*, int> userIds;
    Functions functions(&dummySocket, userIds);

    QString username = "testuser_" + QString::number(rand() % 100000);
    QString password = "123456";

    functions.registerUser(username, password);

    QSqlQuery query;
    query.prepare("SELECT id FROM users WHERE username = :username");
    query.bindValue(":username", username);
    QVERIFY(query.exec());
    QVERIFY(query.next());
}
