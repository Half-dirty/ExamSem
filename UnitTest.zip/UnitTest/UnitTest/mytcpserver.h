#ifndef MYTCPSERVER_H
#define MYTCPSERVER_H

class mytcpserver
{
public:
    mytcpserver();
};

#endif // MYTCPSERVER_H
