#ifndef TEST_FUNCTIONS_H
#define TEST_FUNCTIONS_H

#include <QObject>
#include <QtTest>
#include <QTcpSocket>
#include "functions.h"

class TestFunctions : public QObject {
    Q_OBJECT

private slots:
    void testGetExamListJSON();
    void testRegisterUser();
    void initTestCase();
};

#endif // TEST_FUNCTIONS_H
